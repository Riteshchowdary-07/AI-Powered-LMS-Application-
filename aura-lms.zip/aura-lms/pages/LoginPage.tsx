import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Role } from '../types';

interface LoginPageProps {
    onSwitchToRegister: () => void;
}
const LoginPage: React.FC<LoginPageProps> = ({ onSwitchToRegister }) => {
    const [email, setEmail] = useState('robert@edu.com');
    const [password, setPassword] = useState('password');
    const [role, setRole] = useState<Role>(Role.Teacher);
    const [error, setError] = useState('');
    const { login } = useAuth();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!login(email, password, role)) {
            setError('Invalid credentials for the selected role. Try alice@edu.com (Student) or robert@edu.com (Teacher).');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-slate-100">
            <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-xl shadow-lg">
                <h1 className="text-3xl font-bold text-center text-brand-blue-800">Welcome to Aura LMS</h1>
                <p className="text-center text-slate-500">Sign in to continue your learning journey.</p>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="email" className="text-sm font-medium text-slate-700">Email Address</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            className="w-full px-4 py-2 mt-2 border border-slate-300 rounded-lg focus:ring-brand-blue-500 focus:border-brand-blue-500"
                            placeholder="you@example.com"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="text-sm font-medium text-slate-700">Password</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            className="w-full px-4 py-2 mt-2 border border-slate-300 rounded-lg focus:ring-brand-blue-500 focus:border-brand-blue-500"
                            placeholder="••••••••"
                        />
                    </div>
                    <div>
                        <label className="text-sm font-medium text-slate-700">Login as</label>
                        <div className="flex items-center space-x-4 mt-2">
                            <label className="flex items-center">
                                <input type="radio" name="role" value={Role.Student} checked={role === Role.Student} onChange={() => setRole(Role.Student)} className="text-brand-blue-600 focus:ring-brand-blue-500"/>
                                <span className="ml-2 text-slate-700">Student</span>
                            </label>
                            <label className="flex items-center">
                                <input type="radio" name="role" value={Role.Teacher} checked={role === Role.Teacher} onChange={() => setRole(Role.Teacher)} className="text-brand-blue-600 focus:ring-brand-blue-500"/>
                                <span className="ml-2 text-slate-700">Teacher</span>
                            </label>
                        </div>
                    </div>
                    {error && <p className="text-sm text-red-600">{error}</p>}
                    <button type="submit" className="w-full px-4 py-2 font-semibold text-white bg-brand-blue-600 rounded-lg hover:bg-brand-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue-500">
                        Login
                    </button>
                </form>

                <p className="text-sm text-center text-slate-500">
                    Don't have an account?{' '}
                    <button onClick={onSwitchToRegister} className="font-medium text-brand-blue-600 hover:underline">
                        Register here
                    </button>
                </p>
            </div>
        </div>
    );
};

export default LoginPage;