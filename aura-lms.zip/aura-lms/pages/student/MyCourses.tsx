import React, { useState } from 'react';
import { MOCK_COURSES, MOCK_USERS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { Course, CourseMaterial, FileType } from '../../types';
import Modal from '../../components/common/Modal';

const FileIcon: React.FC<{ fileType: FileType }> = ({ fileType }) => {
    // FIX: Replaced JSX.Element with React.ReactNode to resolve "Cannot find namespace 'JSX'" error.
    const icons: { [key in FileType | 'other']: React.ReactNode } = {
        pdf: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clipRule="evenodd" /></svg>,
        ppt: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-orange-500" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z" /><path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.022 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" /></svg>,
        doc: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" /></svg>,
        other: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-500" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" /></svg>,
    };
    return icons[fileType] || icons.other;
};


const CourseProgressCard: React.FC<{ course: Course; onViewMaterials: (course: Course) => void }> = ({ course, onViewMaterials }) => {
    const teacher = MOCK_USERS.find(u => u.id === course.teacherId);
    // Mock progress
    const progress = Math.floor(Math.random() * (90 - 40 + 1) + 40);
    const hasMaterials = course.materials && course.materials.length > 0;

    return (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-slate-200 hover:shadow-md transition-shadow">
            <div className="p-6">
                <h3 className="text-xl font-semibold text-brand-blue-800">{course.title}</h3>
                <p className="text-sm text-slate-500 mt-1">
                    Taught by <span className="font-medium text-slate-600">{teacher?.name || 'Unknown'}</span>
                </p>
                <div className="mt-4">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-slate-500">Progress</span>
                        <span className="text-sm font-medium text-slate-500">{progress}%</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                        <div className="bg-brand-blue-600 h-2 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 grid grid-cols-2 gap-2">
                 <button 
                    onClick={() => onViewMaterials(course)}
                    disabled={!hasMaterials}
                    className={`w-full text-center px-4 py-2 rounded-md text-sm font-semibold transition ${
                        hasMaterials 
                        ? 'bg-brand-blue-100 text-brand-blue-800 hover:bg-brand-blue-200' 
                        : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                    }`}>
                    View Materials
                </button>
                 <button className="w-full text-center px-4 py-2 rounded-md text-sm font-semibold bg-brand-blue-600 text-white hover:bg-brand-blue-700 transition">
                    Go to Course
                </button>
            </div>
        </div>
    );
};

const MyCourses: React.FC = () => {
    const { user } = useAuth();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

    const handleViewMaterials = (course: Course) => {
        setSelectedCourse(course);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedCourse(null);
    };

    const enrolledCourses = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id));

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Courses</h2>
            <p className="mt-2 text-slate-600">Continue your learning journey and track your progress.</p>

            {enrolledCourses.length > 0 ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                    {enrolledCourses.map(course => (
                        <CourseProgressCard key={course.id} course={course} onViewMaterials={handleViewMaterials} />
                    ))}
                </div>
            ) : (
                <div className="mt-8 text-center bg-white p-12 rounded-lg shadow-sm border">
                    <h3 className="text-xl font-semibold text-slate-700">You are not enrolled in any courses yet.</h3>
                    <p className="text-slate-500 mt-2">Visit the "All Courses" page to find a course and enroll.</p>
                </div>
            )}

            {selectedCourse && (
                 <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={`Course Materials: ${selectedCourse.title}`}>
                    {selectedCourse.materials && selectedCourse.materials.length > 0 ? (
                        <ul className="space-y-3 max-h-96 overflow-y-auto">
                            {selectedCourse.materials.map((material: CourseMaterial) => (
                                <li key={material.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-md">
                                    <div className="flex items-center space-x-3">
                                        <FileIcon fileType={material.fileType} />
                                        <span className="text-slate-700 font-medium">{material.name}</span>
                                    </div>
                                    <a 
                                        href={material.fileUrl} 
                                        download 
                                        className="text-sm font-semibold text-brand-blue-600 hover:underline"
                                    >
                                        Download
                                    </a>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-slate-500">No materials have been uploaded for this course yet.</p>
                    )}
                </Modal>
            )}
        </div>
    );
};

export default MyCourses;