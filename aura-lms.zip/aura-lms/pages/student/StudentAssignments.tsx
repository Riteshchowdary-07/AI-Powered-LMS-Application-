

import React, { useState } from 'react';
import { MOCK_ASSIGNMENTS, MOCK_COURSES, MOCK_SUBMISSIONS } from '../../constants';
import { Assignment, Submission } from '../../types';
import { useAuth } from '../../contexts/AuthContext';

const AssignmentRow: React.FC<{ assignment: Assignment; submission?: Submission }> = ({ assignment, submission }) => {
    const course = MOCK_COURSES.find(c => c.id === assignment.courseId);
    const isSubmitted = !!submission;
    const isOverdue = !isSubmitted && new Date() > assignment.dueDate;

    return (
        <tr className="border-b border-slate-200">
            <td className="py-4 px-6 text-slate-800 font-medium">{assignment.title}</td>
            <td className="py-4 px-6 text-slate-600">{course?.title}</td>
            <td className="py-4 px-6 text-slate-600">{assignment.dueDate.toLocaleDateString()}</td>
            <td className="py-4 px-6">
                {isSubmitted ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Submitted</span>
                ) : isOverdue ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Overdue</span>
                ) : (
                     <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">Pending</span>
                )}
            </td>
            <td className="py-4 px-6 text-right">
                <button className="font-medium text-brand-blue-600 hover:text-brand-blue-800">{isSubmitted ? 'View Submission' : 'Submit'}</button>
            </td>
        </tr>
    );
}

const StudentAssignments: React.FC = () => {
    const { user } = useAuth();
    const studentSubmissions = MOCK_SUBMISSIONS.filter(s => s.studentId === user?.id);
    const studentCourses = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id));
    const studentAssignments = MOCK_ASSIGNMENTS.filter(a => studentCourses.some(c => c.id === a.courseId));

    return (
         <div>
            <h2 className="text-3xl font-bold text-slate-800">Assignments</h2>
            <p className="mt-2 text-slate-600">Keep track of your pending and completed assignments.</p>

            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Title</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Course</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Due Date</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Status</th>
                            <th scope="col" className="relative py-3.5 px-6"><span className="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                       {studentAssignments.map(assignment => {
                           const submission = studentSubmissions.find(s => s.assignmentId === assignment.id);
                           return <AssignmentRow key={assignment.id} assignment={assignment} submission={submission} />
                       })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StudentAssignments;
