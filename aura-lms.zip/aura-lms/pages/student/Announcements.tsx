import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_COURSES, MOCK_ANNOUNCEMENTS } from '../../constants';
import { Announcement } from '../../types';

const AnnouncementCard: React.FC<{ announcement: Announcement }> = ({ announcement }) => {
    const course = MOCK_COURSES.find(c => c.id === announcement.courseId);
    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
            <div className="flex justify-between items-start">
                <div>
                    <p className="text-xs font-semibold uppercase text-brand-blue-600">{course?.title || 'General'}</p>
                    <h3 className="text-xl font-semibold text-slate-800 mt-1">{announcement.title}</h3>
                </div>
                <p className="text-sm text-slate-500">{new Date(announcement.date).toLocaleDateString()}</p>
            </div>
            <p className="text-slate-600 mt-4">{announcement.content}</p>
        </div>
    );
};

const Announcements: React.FC = () => {
    const { user } = useAuth();
    const enrolledCourseIds = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id)).map(c => c.id);
    const announcements = MOCK_ANNOUNCEMENTS
        .filter(a => enrolledCourseIds.includes(a.courseId))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Announcements</h2>
            <p className="mt-2 text-slate-600">Stay up-to-date with the latest news from your courses.</p>
            <div className="space-y-6 mt-8">
                {announcements.length > 0 ? (
                    announcements.map(announcement => <AnnouncementCard key={announcement.id} announcement={announcement} />)
                ) : (
                     <div className="mt-8 text-center bg-white p-12 rounded-lg shadow-sm border">
                        <h3 className="text-xl font-semibold text-slate-700">No announcements right now.</h3>
                        <p className="text-slate-500 mt-2">Check back later for updates from your instructors.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Announcements;