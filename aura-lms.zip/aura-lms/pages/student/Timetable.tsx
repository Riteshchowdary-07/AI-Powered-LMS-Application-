import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_COURSES, MOCK_TIMETABLE } from '../../constants';

const Timetable: React.FC = () => {
    const { user } = useAuth();
    const enrolledCourseIds = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id)).map(c => c.id);
    const studentTimetable = MOCK_TIMETABLE.filter(entry => enrolledCourseIds.includes(entry.courseId));

    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    
    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Timetable</h2>
            <p className="mt-2 text-slate-600">Your weekly class schedule.</p>
            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-5">
                    {days.map(day => (
                        <div key={day} className="text-center font-semibold text-slate-800 p-4 border-b border-r border-slate-200 bg-slate-50">
                            {day}
                        </div>
                    ))}
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-5 min-h-[40rem]">
                    {days.map(day => (
                        <div key={day} className="border-r border-slate-200 p-2 space-y-2">
                            {studentTimetable
                                .filter(entry => entry.day === day)
                                .map(entry => (
                                    <div key={entry.courseId + entry.time} className="bg-brand-blue-50 p-3 rounded-md border border-brand-blue-200">
                                        <p className="font-semibold text-brand-blue-800 text-sm">{entry.courseTitle}</p>
                                        <p className="text-xs text-brand-blue-600 mt-1">{entry.time}</p>
                                    </div>
                                ))
                            }
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Timetable;