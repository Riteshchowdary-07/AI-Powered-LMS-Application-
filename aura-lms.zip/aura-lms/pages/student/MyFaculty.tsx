import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_COURSES, MOCK_USERS } from '../../constants';
import { User } from '../../types';

const FacultyCard: React.FC<{ teacher: User; courses: string[] }> = ({ teacher, courses }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="text-xl font-semibold text-slate-800">{teacher.name}</h3>
        <p className="text-sm text-slate-500 mt-1">{teacher.email}</p>
        <div className="mt-4">
            <h4 className="text-sm font-medium text-slate-600">Courses Taught:</h4>
            <ul className="list-disc list-inside mt-2 text-slate-700 text-sm space-y-1">
                {courses.map(course => <li key={course}>{course}</li>)}
            </ul>
        </div>
    </div>
);

const MyFaculty: React.FC = () => {
    const { user } = useAuth();
    
    const enrolledCourses = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id));
    const teacherIds = [...new Set(enrolledCourses.map(c => c.teacherId))];
    const faculty = MOCK_USERS.filter(u => teacherIds.includes(u.id));

    const getCoursesForTeacher = (teacherId: string) => {
        return enrolledCourses
            .filter(c => c.teacherId === teacherId)
            .map(c => c.title);
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Faculty</h2>
            <p className="mt-2 text-slate-600">Contact information for your course instructors.</p>
            {faculty.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                    {faculty.map(teacher => (
                        <FacultyCard key={teacher.id} teacher={teacher} courses={getCoursesForTeacher(teacher.id)} />
                    ))}
                </div>
            ) : (
                 <p className="text-center text-slate-500 py-10 mt-8">You are not enrolled in any courses with assigned faculty.</p>
            )}
        </div>
    );
};
export default MyFaculty;