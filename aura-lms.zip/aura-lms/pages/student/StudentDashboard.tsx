import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_COURSES, MOCK_ASSIGNMENTS, MOCK_SUBMISSIONS, MOCK_ATTENDANCE, MOCK_TIMETABLE, MOCK_ANNOUNCEMENTS } from '../../constants';

interface StudentDashboardProps {
    setActiveView: (view: string) => void;
}

const StatCard: React.FC<{ title: string; value: string | number; onClick?: () => void; children?: React.ReactNode }> = ({ title, value, onClick, children }) => (
    <div 
        className={`bg-white p-6 rounded-lg shadow-sm border border-slate-200 ${onClick ? 'cursor-pointer hover:border-brand-blue-500 hover:bg-slate-50 transition' : ''}`}
        onClick={onClick}
    >
        <h3 className="text-sm font-medium text-slate-500 uppercase">{title}</h3>
        <p className="text-3xl font-bold text-slate-800 mt-2">{value}</p>
        {children}
    </div>
);

const StudentDashboard: React.FC<StudentDashboardProps> = ({ setActiveView }) => {
    const { user } = useAuth();

    // Calculations
    const enrolledCourses = MOCK_COURSES.filter(c => c.studentIds.includes(user!.id));
    const enrolledCourseIds = enrolledCourses.map(c => c.id);
    const studentSubmissions = MOCK_SUBMISSIONS.filter(s => s.studentId === user!.id);
    
    const pendingAssignments = MOCK_ASSIGNMENTS.filter(a => 
        enrolledCourseIds.includes(a.courseId) && 
        !studentSubmissions.some(s => s.assignmentId === a.id) &&
        new Date() < a.dueDate
    ).length;

    const studentAttendance = MOCK_ATTENDANCE.filter(att => att.studentId === user?.id);
    const presentCount = studentAttendance.filter(att => att.status === 'present').length;
    const attendancePercentage = studentAttendance.length > 0 ? Math.round((presentCount / studentAttendance.length) * 100) : 100;

    const todayDay = new Date().toLocaleDateString('en-US', { weekday: 'long' });
    const todaysClasses = MOCK_TIMETABLE.filter(t => enrolledCourseIds.includes(t.courseId) && t.day === todayDay).length;

    const announcements = MOCK_ANNOUNCEMENTS
        .filter(a => enrolledCourseIds.includes(a.courseId))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 2);


    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Welcome, {user?.name}!</h2>
            <p className="mt-2 text-slate-600">Here's a quick look at your learning progress today.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
                <StatCard title="Enrolled Courses" value={enrolledCourses.length} onClick={() => setActiveView('my_courses')} />
                <StatCard title="Pending Assignments" value={pendingAssignments} onClick={() => setActiveView('assignments')} />
                <StatCard title="Overall Attendance" value={`${attendancePercentage}%`} onClick={() => setActiveView('attendance')} />
                <StatCard title="Today's Classes" value={todaysClasses} onClick={() => setActiveView('timetable')} />
            </div>

            <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
                    <h3 className="text-xl font-semibold text-slate-800">Quick Links</h3>
                     <div className="grid grid-cols-2 gap-4 mt-4">
                        <button onClick={() => setActiveView('grades')} className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left font-medium text-slate-700">View My Grades</button>
                        <button onClick={() => setActiveView('faculty')} className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left font-medium text-slate-700">Contact Faculty</button>
                        <button onClick={() => setActiveView('all_courses')} className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left font-medium text-slate-700">Explore New Courses</button>
                        <button onClick={() => setActiveView('forum')} className="p-4 bg-slate-50 hover:bg-slate-100 rounded-lg text-left font-medium text-slate-700">Go to Forum</button>
                    </div>
                </div>
                 <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
                    <h3 className="text-xl font-semibold text-slate-800">Recent Announcements</h3>
                    {announcements.length > 0 ? (
                        <ul className="mt-4 space-y-3">
                            {announcements.map(ann => {
                                const course = MOCK_COURSES.find(c => c.id === ann.courseId);
                                return(
                                    <li key={ann.id} className="p-3 bg-slate-50 rounded-md">
                                        <p className="font-semibold text-slate-700">{ann.title}</p>
                                        <p className="text-sm text-slate-500">From {course?.title}</p>
                                    </li>
                                )
                            })}
                        </ul>
                    ) : (
                        <p className="text-slate-500 mt-2">No new announcements.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default StudentDashboard;