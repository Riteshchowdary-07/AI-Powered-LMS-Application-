

import React from 'react';
import { MOCK_ASSIGNMENTS, MOCK_COURSES, MOCK_SUBMISSIONS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { Submission } from '../../types';

const GradeRow: React.FC<{ submission: Submission }> = ({ submission }) => {
    const assignment = MOCK_ASSIGNMENTS.find(a => a.id === submission.assignmentId);
    const course = MOCK_COURSES.find(c => c.id === assignment?.courseId);

    const getGradeColor = (grade: number) => {
        if (grade >= 90) return 'text-green-600';
        if (grade >= 80) return 'text-blue-600';
        if (grade >= 70) return 'text-yellow-600';
        return 'text-red-600';
    };

    return (
        <tr className="border-b border-slate-200">
            <td className="py-4 px-6 text-slate-800 font-medium">{assignment?.title}</td>
            <td className="py-4 px-6 text-slate-600">{course?.title}</td>
            <td className={`py-4 px-6 font-bold text-lg ${getGradeColor(submission.grade!)}`}>{submission.grade}%</td>
            <td className="py-4 px-6 text-slate-600 italic">"{submission.feedback}"</td>
        </tr>
    );
};


const StudentGrades: React.FC = () => {
    const { user } = useAuth();
    const gradedSubmissions = MOCK_SUBMISSIONS.filter(s => s.studentId === user?.id && s.grade !== undefined);
    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Grades</h2>
            <p className="mt-2 text-slate-600">Here's a summary of your performance across all courses.</p>
            
             <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Assignment</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Course</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Grade</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Feedback</th>
                        </tr>
                    </thead>
                     <tbody className="divide-y divide-slate-200 bg-white">
                        {gradedSubmissions.map(sub => (
                            <GradeRow key={sub.id} submission={sub} />
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StudentGrades;
