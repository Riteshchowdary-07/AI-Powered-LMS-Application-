
import React, { useState } from 'react';
import { MOCK_COURSES, MOCK_USERS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { Course } from '../../types';

const CourseCard: React.FC<{ course: Course, onEnroll: (courseId: string) => void, isEnrolled: boolean }> = ({ course, onEnroll, isEnrolled }) => {
    const teacher = MOCK_USERS.find(u => u.id === course.teacherId);
    return (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-slate-200 hover:shadow-md transition-shadow">
            <div className="p-6">
                <h3 className="text-xl font-semibold text-brand-blue-800">{course.title}</h3>
                <p className="text-sm text-slate-500 mt-1">
                    Taught by <span className="font-medium text-slate-600">{teacher?.name || 'Unknown'}</span>
                </p>
                <p className="text-slate-600 mt-4 text-sm h-20">{course.description}</p>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center">
                <span className="text-sm font-medium text-slate-500">{course.duration}</span>
                <button 
                    onClick={() => onEnroll(course.id)}
                    disabled={isEnrolled}
                    className={`px-4 py-2 rounded-md text-sm font-semibold transition ${isEnrolled ? 'bg-slate-200 text-slate-500 cursor-not-allowed' : 'bg-brand-blue-600 text-white hover:bg-brand-blue-700'}`}>
                    {isEnrolled ? 'Enrolled' : 'Enroll Now'}
                </button>
            </div>
        </div>
    );
};

const AllCourses: React.FC = () => {
    const { user } = useAuth();
    // In a real app, this would be part of the user's data from a database
    const [enrolledCourses, setEnrolledCourses] = useState<string[]>(
        MOCK_COURSES.filter(c => c.studentIds.includes(user!.id)).map(c => c.id)
    );

    const handleEnroll = (courseId: string) => {
        setEnrolledCourses(prev => [...prev, courseId]);
        // Here you would also make an API call
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Explore Courses</h2>
            <p className="mt-2 text-slate-600">Find your next learning adventure. Enroll in a course to get started.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                {MOCK_COURSES.map(course => (
                    <CourseCard key={course.id} course={course} onEnroll={handleEnroll} isEnrolled={enrolledCourses.includes(course.id)} />
                ))}
            </div>
        </div>
    );
};

export default AllCourses;
