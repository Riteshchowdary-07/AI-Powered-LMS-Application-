import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_ATTENDANCE } from '../../constants';
import { Attendance } from '../../types';

const StatCard: React.FC<{ title: string; value: string | number; }> = ({ title, value }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="text-sm font-medium text-slate-500 uppercase">{title}</h3>
        <p className="text-3xl font-bold text-slate-800 mt-2">{value}</p>
    </div>
);

const AttendanceRow: React.FC<{ record: Attendance }> = ({ record }) => {
    const statusClasses = record.status === 'present' 
        ? 'bg-green-100 text-green-800'
        : 'bg-red-100 text-red-800';

    return (
        <tr className="border-b border-slate-200">
            <td className="py-4 px-6 text-slate-800 font-medium">{new Date(record.date).toLocaleDateString('en-CA')}</td>
            <td className="py-4 px-6">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusClasses}`}>
                    {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                </span>
            </td>
        </tr>
    );
};

const StudentAttendance: React.FC = () => {
    const { user } = useAuth();
    const studentAttendance = MOCK_ATTENDANCE.filter(att => att.studentId === user?.id)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const totalDays = studentAttendance.length;
    const presentDays = studentAttendance.filter(a => a.status === 'present').length;
    const attendancePercentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 100;

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Attendance</h2>
            <p className="mt-2 text-slate-600">Here is your attendance record for all courses.</p>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <StatCard title="Overall Attendance" value={`${attendancePercentage}%`} />
                <StatCard title="Total Classes" value={totalDays} />
            </div>

            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Date</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Status</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                        {studentAttendance.length > 0 ? (
                            studentAttendance.map(record => (
                                <AttendanceRow key={record.id} record={record} />
                            ))
                        ) : (
                            <tr>
                                <td colSpan={2} className="text-center py-10 text-slate-500">
                                    No attendance records found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StudentAttendance;