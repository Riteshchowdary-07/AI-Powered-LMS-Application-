

import React from 'react';
import { MOCK_COURSES, MOCK_USERS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { User } from '../../types';

const StudentRow: React.FC<{ student: User }> = ({ student }) => (
    <tr className="border-b border-slate-200">
        <td className="py-4 px-6 text-slate-800 font-medium">{student.name}</td>
        <td className="py-4 px-6 text-slate-600">{student.email}</td>
        <td className="py-4 px-6 text-right">
            <button className="font-medium text-brand-blue-600 hover:text-brand-blue-800">View Progress</button>
        </td>
    </tr>
);

const ViewStudents: React.FC = () => {
    const { user } = useAuth();
    
    // Get all unique student IDs from courses taught by the current teacher
    const teacherCourses = MOCK_COURSES.filter(c => c.teacherId === user?.id);
    const studentIds = new Set<string>();
    teacherCourses.forEach(course => {
        course.studentIds.forEach(studentId => {
            studentIds.add(studentId);
        });
    });

    const students = MOCK_USERS.filter(u => studentIds.has(u.id));

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">My Students</h2>
            <p className="mt-2 text-slate-600">A list of all students enrolled in your courses.</p>
            
            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Name</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Email</th>
                            <th scope="col" className="relative py-3.5 px-6"><span className="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                        {students.map(student => (
                            <StudentRow key={student.id} student={student} />
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ViewStudents;
