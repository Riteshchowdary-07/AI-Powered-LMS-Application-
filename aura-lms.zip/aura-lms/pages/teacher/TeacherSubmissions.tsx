
import React from 'react';
import { MOCK_ASSIGNMENTS, MOCK_COURSES, MOCK_SUBMISSIONS, MOCK_USERS } from '../../constants';
import { Submission } from '../../types';
import { useAuth } from '../../contexts/AuthContext';

const SubmissionRow: React.FC<{ submission: Submission }> = ({ submission }) => {
    const student = MOCK_USERS.find(u => u.id === submission.studentId);
    const assignment = MOCK_ASSIGNMENTS.find(a => a.id === submission.assignmentId);
    const course = MOCK_COURSES.find(c => c.id === assignment?.courseId);
    
    return (
         <tr className="border-b border-slate-200">
            <td className="py-4 px-6 text-slate-800 font-medium">{student?.name}</td>
            <td className="py-4 px-6 text-slate-600">{assignment?.title}</td>
            <td className="py-4 px-6 text-slate-600">{course?.title}</td>
            <td className="py-4 px-6 text-slate-600">{submission.submittedAt.toLocaleDateString()}</td>
            <td className="py-4 px-6">
                 {submission.grade ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">Graded</span>
                ) : (
                     <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">Needs Grading</span>
                )}
            </td>
            <td className="py-4 px-6 text-right">
                <button className="font-medium text-brand-blue-600 hover:text-brand-blue-800">Review</button>
            </td>
        </tr>
    );
};

const TeacherSubmissions: React.FC = () => {
    const { user } = useAuth();
    // Get courses taught by this teacher
    const teacherCourseIds = MOCK_COURSES.filter(c => c.teacherId === user?.id).map(c => c.id);
    // Get assignments for those courses
    const teacherAssignmentIds = MOCK_ASSIGNMENTS.filter(a => teacherCourseIds.includes(a.courseId)).map(a => a.id);
    // Get submissions for those assignments
    const teacherSubmissions = MOCK_SUBMISSIONS.filter(s => teacherAssignmentIds.includes(s.assignmentId));

    return (
         <div>
            <h2 className="text-3xl font-bold text-slate-800">Student Submissions</h2>
            <p className="mt-2 text-slate-600">Review and grade submitted assignments from your students.</p>

            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Student</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Assignment</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Course</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Submitted At</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Status</th>
                            <th scope="col" className="relative py-3.5 px-6"><span className="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                       {teacherSubmissions.map(submission => (
                           <SubmissionRow key={submission.id} submission={submission} />
                       ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default TeacherSubmissions;
