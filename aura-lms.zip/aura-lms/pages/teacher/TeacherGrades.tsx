import React from 'react';
import { MOCK_COURSES, MOCK_SUBMISSIONS, MOCK_USERS, MOCK_ASSIGNMENTS } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { Submission } from '../../types';

const TeacherGradeRow: React.FC<{ submission: Submission }> = ({ submission }) => {
    const student = MOCK_USERS.find(u => u.id === submission.studentId);
    return (
        <tr className="border-b border-slate-200">
            <td className="py-4 px-6 text-slate-800 font-medium">{student?.name}</td>
            <td className="py-4 px-6 font-bold text-slate-700">{submission.grade || 'N/A'}%</td>
            <td className="py-4 px-6 text-slate-600">{submission.feedback || '-'}</td>
             <td className="py-4 px-6 text-right">
                <button className="font-medium text-brand-blue-600 hover:text-brand-blue-800">Edit Grade</button>
            </td>
        </tr>
    );
}

const TeacherGrades: React.FC = () => {
    const { user } = useAuth();
    // This is simplified. A real gradebook would be organized by course and assignment.
    const teacherCourseIds = MOCK_COURSES.filter(c => c.teacherId === user?.id).map(c => c.id);
    const submissionsForTeacher = MOCK_SUBMISSIONS.filter(s => 
        MOCK_COURSES.some(c => c.id === MOCK_ASSIGNMENTS.find(a => a.id === s.assignmentId)?.courseId && teacherCourseIds.includes(c.id))
    );

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Gradebook</h2>
            <p className="mt-2 text-slate-600">View and manage grades for all students across your courses.</p>
            
            <div className="mt-8 bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-4">
                    {/* Add filters for courses/assignments here */}
                    <h3 className="text-lg font-semibold text-slate-800">All Submissions</h3>
                </div>
                <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                        <tr>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Student</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Grade</th>
                            <th scope="col" className="py-3.5 px-6 text-left text-sm font-semibold text-slate-900">Feedback</th>
                            <th scope="col" className="relative py-3.5 px-6"><span className="sr-only">Actions</span></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                        {submissionsForTeacher.map(sub => (
                            <TeacherGradeRow key={sub.id} submission={sub} />
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default TeacherGrades;