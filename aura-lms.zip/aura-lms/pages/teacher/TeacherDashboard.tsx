import React, { useState, useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_COURSES, MOCK_SUBMISSIONS, MOCK_USERS, MOCK_ATTENDANCE } from '../../constants';
import Modal from '../../components/common/Modal';
import { User, Attendance, AttendanceStatus } from '../../types';

interface TeacherDashboardProps {
    setActiveView: (view: string) => void;
}

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; color: string; children?: React.ReactNode }> = ({ title, value, icon, color, children }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <div className="flex items-start justify-between">
            <div>
                <h3 className="text-sm font-medium text-slate-500 uppercase">{title}</h3>
                <p className="text-3xl font-bold text-slate-800 mt-2">{value}</p>
                 {children}
            </div>
            <div className={`p-3 rounded-full ${color}`}>
                {icon}
            </div>
        </div>
    </div>
);

const QuickActionButton: React.FC<{ label: string; onClick: () => void; icon: React.ReactNode }> = ({ label, onClick, icon }) => (
    <button 
        onClick={onClick} 
        className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-sm border text-center hover:border-brand-blue-500 hover:bg-brand-blue-50 transition-colors group"
    >
        <div className="mb-2 text-brand-blue-600 group-hover:text-brand-blue-700">
            {icon}
        </div>
        <span className="text-sm font-medium text-slate-700">{label}</span>
    </button>
);

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ setActiveView }) => {
    const { user } = useAuth();

    const [isUploadModalOpen, setUploadModalOpen] = useState(false);
    const [isAnnounceModalOpen, setAnnounceModalOpen] = useState(false);
    const [isTimetableModalOpen, setTimetableModalOpen] = useState(false);
    const [isAttendanceModalOpen, setAttendanceModalOpen] = useState(false);
    
    // Holds the changes for the attendance modal
    const [attendanceData, setAttendanceData] = useState<Record<string, AttendanceStatus>>({});
    // Holds the "source of truth" for all attendance records
    const [allAttendance, setAllAttendance] = useState<Attendance[]>(MOCK_ATTENDANCE);

    const teacherCourses = useMemo(() => MOCK_COURSES.filter(c => c.teacherId === user?.id), [user?.id]);
    const submissionsToGrade = useMemo(() => MOCK_SUBMISSIONS.filter(s => teacherCourses.some(c => MOCK_COURSES.find(mc => mc.id === s.assignmentId)?.teacherId === user?.id) && !s.grade), [teacherCourses, user?.id]);
    const teacherStudents = useMemo(() => {
        const studentIds = new Set<string>();
        teacherCourses.forEach(course => course.studentIds.forEach(id => studentIds.add(id)));
        return MOCK_USERS.filter(u => studentIds.has(u.id));
    }, [teacherCourses]);

    const today = new Date().toISOString().split('T')[0];
    const todaysAttendance = useMemo(() => allAttendance.filter(a => a.date === today && teacherStudents.some(s => s.id === a.studentId)), [allAttendance, today, teacherStudents]);
    const presentStudents = useMemo(() => todaysAttendance.filter(a => a.status === 'present').length, [todaysAttendance]);
    const absentStudents = teacherStudents.length - presentStudents;

    const handleAttendanceChange = (studentId: string, status: AttendanceStatus) => {
        setAttendanceData(prev => ({ ...prev, [studentId]: status }));
    };
    
    const handleSaveAttendance = () => {
        console.log("Saving attendance:", attendanceData);
        
        const todayStr = new Date().toISOString().split('T')[0];
        let updatedRecords = [...allAttendance];

        Object.entries(attendanceData).forEach(([studentId, status]) => {
            const recordIndex = updatedRecords.findIndex(
                rec => rec.studentId === studentId && rec.date === todayStr
            );
            if (recordIndex !== -1) {
                // Update existing record
                updatedRecords[recordIndex] = { ...updatedRecords[recordIndex], status };
            } else {
                // Add new record
                updatedRecords.push({
                    id: `att-${Date.now()}-${studentId}`,
                    studentId,
                    date: todayStr,
                    status,
                });
            }
        });

        setAllAttendance(updatedRecords);
        alert('Attendance marked successfully!');
        setAttendanceModalOpen(false);
    };
    
    const openAttendanceModal = () => {
        const initialData: Record<string, AttendanceStatus> = {};
        teacherStudents.forEach(student => {
            const todaysRecord = todaysAttendance.find(rec => rec.studentId === student.id);
            initialData[student.id] = todaysRecord ? todaysRecord.status : 'absent';
        });
        setAttendanceData(initialData);
        setAttendanceModalOpen(true);
    };

    const icons = {
        courses: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 6.253v11.494m-5.25-6.062h10.5M5.25 18.375h10.5" /></svg>,
        students: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm6-11a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
        submissions: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>,
        attendance: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>,
    };

    const actionIcons = {
        create: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
        upload: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>,
        announce: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-2.104 9.168-5.182C17.025 3.188 16.5 6.159 16.5 8.351v8.139a4.002 4.002 0 01-3.248 3.96l-3.053.611A5.5 5.5 0 015.436 13.683z" /></svg>,
        timetable: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
        attendance: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>,
        viewStudents: <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>,
    };

    const actions = [
        { label: "Create Course", onClick: () => setActiveView('create_course'), icon: actionIcons.create },
        { label: "Upload Grades", onClick: () => setUploadModalOpen(true), icon: actionIcons.upload },
        { label: "Send Announcement", onClick: () => setAnnounceModalOpen(true), icon: actionIcons.announce },
        { label: "Set Timetable", onClick: () => setTimetableModalOpen(true), icon: actionIcons.timetable },
        { label: "Mark Attendance", onClick: openAttendanceModal, icon: actionIcons.attendance },
        { label: "View Students", onClick: () => setActiveView('view_students'), icon: actionIcons.viewStudents },
    ];


    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Welcome, {user?.name}!</h2>
            <p className="mt-2 text-slate-600">Manage your courses, students, and content from here.</p>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
                <StatCard title="Total Courses" value={teacherCourses.length} icon={icons.courses} color="bg-blue-100" />
                <StatCard title="Total Students" value={teacherStudents.length} icon={icons.students} color="bg-green-100" />
                <StatCard title="Submissions to Grade" value={submissionsToGrade.length} icon={icons.submissions} color="bg-yellow-100" />
                <StatCard title="Today's Attendance" value={`${presentStudents}/${teacherStudents.length}`} icon={icons.attendance} color="bg-indigo-100">
                    <p className="text-sm text-slate-500 mt-2"><span className="font-semibold text-green-600">{presentStudents} Present</span>, <span className="font-semibold text-red-600">{absentStudents} Absent</span></p>
                </StatCard>
            </div>

            {/* Quick Actions */}
            <div className="mt-10">
                <h3 className="text-xl font-semibold text-slate-800 mb-4">Quick Actions</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                     {actions.map(action => (
                        <QuickActionButton key={action.label} {...action} />
                    ))}
                </div>
            </div>

            {/* Recent Submissions */}
            <div className="mt-10 bg-white p-6 rounded-lg shadow-sm border border-slate-200">
                <h3 className="text-xl font-semibold text-slate-800">Recent Submissions to Grade</h3>
                {submissionsToGrade.length > 0 ? (
                    <ul className="mt-4 space-y-3">
                    {submissionsToGrade.slice(0, 3).map(sub => {
                        const student = MOCK_USERS.find(u => u.id === sub.studentId);
                        return (
                        <li key={sub.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-md">
                            <p className="text-slate-700">{student?.name} submitted an assignment.</p>
                            <button onClick={() => setActiveView('submissions')} className="text-sm font-semibold text-brand-blue-600 hover:underline">Review</button>
                        </li>
                        )
                    })}
                    </ul>
                ) : (
                    <p className="text-slate-500 mt-2">No new submissions to show.</p>
                )}
            </div>

             {/* Modals */}
             <Modal isOpen={isUploadModalOpen} onClose={() => setUploadModalOpen(false)} title="Upload Grades">
                <p className="text-slate-600 mb-4">Select a CSV file with student IDs and grades to upload.</p>
                <input type="file" className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"/>
                <div className="text-right mt-6">
                    <button onClick={() => setUploadModalOpen(false)} className="px-4 py-2 bg-brand-blue-600 text-white rounded-lg hover:bg-brand-blue-700">Upload</button>
                </div>
            </Modal>
             <Modal isOpen={isAnnounceModalOpen} onClose={() => setAnnounceModalOpen(false)} title="Send Announcement">
                <textarea placeholder="Write your announcement here..." rows={4} className="w-full p-2 border rounded-md"></textarea>
                 <div className="text-right mt-4">
                    <button onClick={() => setAnnounceModalOpen(false)} className="px-4 py-2 bg-brand-blue-600 text-white rounded-lg hover:bg-brand-blue-700">Send</button>
                </div>
            </Modal>
             <Modal isOpen={isTimetableModalOpen} onClose={() => setTimetableModalOpen(false)} title="Set Timetable">
                <p>Timetable management interface would go here.</p>
            </Modal>
            <Modal isOpen={isAttendanceModalOpen} onClose={() => setAttendanceModalOpen(false)} title={`Mark Attendance for ${today}`}>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                    {teacherStudents.map(student => (
                        <div key={student.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-md">
                            <p className="font-medium text-slate-800">{student.name}</p>
                            <div className="flex items-center space-x-4">
                                <label className="flex items-center">
                                    <input 
                                        type="radio" 
                                        name={`attendance-${student.id}`} 
                                        value="present" 
                                        checked={attendanceData[student.id] === 'present'} 
                                        onChange={() => handleAttendanceChange(student.id, 'present')}
                                        className="text-green-600 focus:ring-green-500"
                                    />
                                    <span className="ml-2 text-green-700">Present</span>
                                </label>
                                <label className="flex items-center">
                                    <input 
                                        type="radio" 
                                        name={`attendance-${student.id}`} 
                                        value="absent" 
                                        checked={attendanceData[student.id] === 'absent'} 
                                        onChange={() => handleAttendanceChange(student.id, 'absent')}
                                        className="text-red-600 focus:ring-red-500"
                                    />
                                    <span className="ml-2 text-red-700">Absent</span>
                                </label>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="text-right mt-6">
                    <button onClick={handleSaveAttendance} className="px-5 py-2 bg-brand-blue-600 text-white rounded-lg hover:bg-brand-blue-700">Save Attendance</button>
                </div>
            </Modal>

        </div>
    );
};

export default TeacherDashboard;
