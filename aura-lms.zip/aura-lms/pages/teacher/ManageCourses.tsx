import React from 'react';
import { MOCK_COURSES } from '../../constants';
import { useAuth } from '../../contexts/AuthContext';
import { Course } from '../../types';

const CourseManagementCard: React.FC<{ course: Course }> = ({ course }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex flex-col justify-between">
            <div>
                <h3 className="text-xl font-semibold text-brand-blue-800">{course.title}</h3>
                <p className="text-sm text-slate-500 mt-1">{course.studentIds.length} student(s) enrolled</p>
                <p className="text-slate-600 mt-4 text-sm h-20">{course.description}</p>
            </div>
            <div className="mt-6 flex items-center space-x-4">
                <button className="flex-1 text-center px-4 py-2 rounded-md text-sm font-semibold bg-brand-blue-100 text-brand-blue-800 hover:bg-brand-blue-200 transition">
                    Edit Course
                </button>
                <button className="flex-1 text-center px-4 py-2 rounded-md text-sm font-semibold bg-red-100 text-red-800 hover:bg-red-200 transition">
                    Delete
                </button>
            </div>
        </div>
    );
};

const ManageCourses: React.FC = () => {
    const { user } = useAuth();
    const teacherCourses = MOCK_COURSES.filter(c => c.teacherId === user!.id);

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Manage Your Courses</h2>
            <p className="mt-2 text-slate-600">Edit course details, manage assignments, and view enrolled students.</p>

            {teacherCourses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                    {teacherCourses.map(course => (
                        <CourseManagementCard key={course.id} course={course} />
                    ))}
                </div>
            ) : (
                <div className="mt-8 text-center bg-white p-12 rounded-lg shadow-sm border">
                    <h3 className="text-xl font-semibold text-slate-700">You haven't created any courses yet.</h3>
                    <p className="text-slate-500 mt-2">Visit the "Create Course" page to get started.</p>
                </div>
            )}
        </div>
    );
};

export default ManageCourses;
