
import React, { useState } from 'react';

interface CreateCourseProps {
    setActiveView: (view: string) => void;
}

const CreateCourse: React.FC<CreateCourseProps> = ({ setActiveView }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [duration, setDuration] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Mock submission
        console.log({ title, description, duration });
        alert('Course created successfully! (mock)');
        setActiveView('manage_courses');
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Create a New Course</h2>
            <p className="mt-2 text-slate-600">Fill out the details below to launch your new course.</p>

            <div className="mt-8 max-w-2xl">
                <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-sm border border-slate-200 space-y-6">
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-slate-700">Course Title</label>
                        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="mt-1 block w-full px-4 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-brand-blue-500 focus:border-brand-blue-500" required />
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-slate-700">Course Description</label>
                        <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={4} className="mt-1 block w-full px-4 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-brand-blue-500 focus:border-brand-blue-500" required></textarea>
                    </div>
                    <div>
                        <label htmlFor="duration" className="block text-sm font-medium text-slate-700">Course Duration</label>
                        <input type="text" id="duration" value={duration} onChange={e => setDuration(e.target.value)} className="mt-1 block w-full px-4 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-brand-blue-500 focus:border-brand-blue-500" placeholder="e.g., 8 Weeks" required />
                    </div>

                    <div className="text-right">
                        <button type="submit" className="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-brand-blue-600 hover:bg-brand-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue-500">
                            Create Course
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateCourse;
