import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Role } from '../types';
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';

// Student Pages
import StudentDashboard from './student/StudentDashboard';
import MyCourses from './student/MyCourses';
import AllCourses from './student/AllCourses';
import StudentAssignments from './student/StudentAssignments';
import StudentGrades from './student/StudentGrades';
import StudentAttendance from './student/StudentAttendance';
import MyFaculty from './student/MyFaculty';
import Announcements from './student/Announcements';
import Timetable from './student/Timetable';

// Teacher Pages
import TeacherDashboard from './teacher/TeacherDashboard';
import CreateCourse from './teacher/CreateCourse';
import ManageCourses from './teacher/ManageCourses';
import TeacherSubmissions from './teacher/TeacherSubmissions';
import TeacherGrades from './teacher/TeacherGrades';
import ViewStudents from './teacher/ViewStudents';

// Shared Pages
import Forum from './shared/Forum';

const DashboardPage: React.FC = () => {
    const { user } = useAuth();
    // Default view is the dashboard for the respective role
    const defaultView = user?.role === Role.Student ? 'dashboard_student' : 'dashboard_teacher';
    const [activeView, setActiveView] = useState(defaultView);

    const renderStudentContent = () => {
        switch (activeView) {
            case 'dashboard_student': return <StudentDashboard setActiveView={setActiveView} />;
            case 'my_courses': return <MyCourses />;
            case 'all_courses': return <AllCourses />;
            case 'assignments': return <StudentAssignments />;
            case 'grades': return <StudentGrades />;
            case 'attendance': return <StudentAttendance />;
            case 'faculty': return <MyFaculty />;
            case 'announcements': return <Announcements />;
            case 'timetable': return <Timetable />;
            case 'forum': return <Forum />;
            default: return <StudentDashboard setActiveView={setActiveView} />;
        }
    };

    const renderTeacherContent = () => {
         switch (activeView) {
            case 'dashboard_teacher': return <TeacherDashboard setActiveView={setActiveView} />;
            case 'create_course': return <CreateCourse setActiveView={setActiveView} />;
            case 'manage_courses': return <ManageCourses />;
            case 'submissions': return <TeacherSubmissions />;
            case 'grades': return <TeacherGrades />;
            case 'view_students': return <ViewStudents />;
            case 'forum': return <Forum />;
            default: return <TeacherDashboard setActiveView={setActiveView} />;
        }
    };
    
    const renderContent = () => {
        if (!user) return null; // Or a loading spinner
        return user.role === Role.Student ? renderStudentContent() : renderTeacherContent();
    };

    return (
        <div className="flex h-screen bg-slate-50">
            <Sidebar activeView={activeView} setActiveView={setActiveView} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-50">
                    <div className="container mx-auto px-6 py-8">
                        {renderContent()}
                    </div>
                </main>
            </div>
        </div>
    );
};

export default DashboardPage;
