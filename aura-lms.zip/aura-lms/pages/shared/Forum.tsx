

import React from 'react';
import { MOCK_FORUM_POSTS, MOCK_USERS } from '../../constants';
import { ForumPost } from '../../types';

const Post: React.FC<{ post: ForumPost, level: number }> = ({ post, level }) => {
    const author = MOCK_USERS.find(u => u.id === post.authorId);
    return (
        <div className={`bg-white p-4 rounded-lg border border-slate-200 ${level > 0 ? 'ml-8 mt-4' : 'mt-4'}`}>
            <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-brand-blue-200 text-brand-blue-800 flex items-center justify-center font-bold text-sm">
                    {author?.name.charAt(0)}
                </div>
                <div>
                    <p className="font-semibold text-slate-800">{author?.name}</p>
                    <p className="text-xs text-slate-500">{post.createdAt.toLocaleString()}</p>
                </div>
            </div>
            <p className="mt-3 text-slate-700">{post.content}</p>
            <div className="mt-2">
                <button className="text-sm font-medium text-brand-blue-600 hover:underline">Reply</button>
            </div>
            {post.replies.map(reply => <Post key={reply.id} post={reply} level={level + 1} />)}
        </div>
    );
};

const Forum: React.FC = () => {
    return (
        <div>
            <h2 className="text-3xl font-bold text-slate-800">Discussion Forum</h2>
            <p className="mt-2 text-slate-600">Engage with your peers and instructors.</p>
            
            <div className="mt-8 max-w-4xl">
                <div className="bg-white p-4 rounded-lg shadow-sm border">
                    <textarea placeholder="Start a new discussion..." rows={3} className="w-full p-2 border border-slate-300 rounded-md focus:ring-brand-blue-500 focus:border-brand-blue-500"></textarea>
                    <div className="text-right mt-2">
                        <button className="px-4 py-2 bg-brand-blue-600 text-white font-semibold rounded-md hover:bg-brand-blue-700">Post</button>
                    </div>
                </div>

                {MOCK_FORUM_POSTS.map(post => (
                    <Post key={post.id} post={post} level={0} />
                ))}
            </div>
        </div>
    );
};

export default Forum;
