import React, { createContext, useState, useContext, ReactNode } from 'react';
import { User, Role } from '../types';
import { MOCK_USERS } from '../constants';

interface AuthContextType {
    user: User | null;
    login: (email: string, pass: string, role: Role) => boolean;
    logout: () => void;
    register: (name: string, email: string, pass: string, role: Role) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);

    // Mock login
    const login = (email: string, pass: string, role: Role): boolean => {
        // In a real app, you'd validate the password
        const foundUser = MOCK_USERS.find(u => u.email === email && u.role === role);
        if (foundUser) {
            setUser(foundUser);
            return true;
        }
        return false;
    };

    const logout = () => {
        setUser(null);
    };

    // Mock register
    const register = (name: string, email: string, pass: string, role: Role): boolean => {
        const newUser: User = { id: `u${MOCK_USERS.length + 1}`, name, email, role };
        // In a real app, save to a database. Here we just log in as the new user.
        console.log("New user registered (mock):", newUser);
        setUser(newUser);
        return true;
    };


    return (
        <AuthContext.Provider value={{ user, login, logout, register }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = (): AuthContextType => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
