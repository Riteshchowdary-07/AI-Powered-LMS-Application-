
import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { MOCK_NOTIFICATIONS } from '../../constants';

const UserIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
        <path fillRule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438Z" clipRule="evenodd" />
    </svg>
);
const BellIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0" />
    </svg>
);
const SearchIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-400">
        <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
    </svg>
);


const Header: React.FC = () => {
    const { user, logout } = useAuth();
    const [profileOpen, setProfileOpen] = useState(false);
    const [notificationsOpen, setNotificationsOpen] = useState(false);
    const userNotifications = MOCK_NOTIFICATIONS.filter(n => n.userId === user?.id);
    const unreadCount = userNotifications.filter(n => !n.read).length;

    return (
        <header className="bg-white border-b border-slate-200">
            <div className="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
                {/* Search bar */}
                <div className="relative">
                    <SearchIcon />
                    <input
                        type="search"
                        placeholder="Search courses..."
                        className="w-full sm:w-64 md:w-96 pl-8 pr-4 py-2 rounded-lg bg-slate-100 border-transparent focus:bg-white focus:border-brand-blue-500 focus:ring-brand-blue-500 transition"
                    />
                </div>

                {/* Right side icons */}
                <div className="flex items-center space-x-4">
                    <div className="relative">
                        <button onClick={() => setNotificationsOpen(!notificationsOpen)} className="p-2 rounded-full hover:bg-slate-100 text-slate-500">
                           <BellIcon />
                           {unreadCount > 0 && <span className="absolute top-1 right-1 block h-2.5 w-2.5 rounded-full bg-red-500 border-2 border-white"></span>}
                        </button>
                        {notificationsOpen && (
                            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-slate-200 z-10">
                                <div className="p-4 font-semibold border-b">Notifications</div>
                                <ul className="py-1 max-h-80 overflow-y-auto">
                                    {userNotifications.map(n => (
                                        <li key={n.id} className={`p-4 text-sm ${!n.read ? 'bg-brand-blue-50' : ''}`}>
                                            <p className="text-slate-700">{n.message}</p>
                                            <p className="text-xs text-slate-400 mt-1">{n.createdAt.toLocaleDateString()}</p>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                    <div className="relative">
                        <button onClick={() => setProfileOpen(!profileOpen)} className="flex items-center space-x-2 p-2 rounded-full hover:bg-slate-100">
                            <div className="w-8 h-8 rounded-full bg-brand-blue-500 text-white flex items-center justify-center">
                                <UserIcon />
                            </div>
                            <span className="hidden sm:inline font-medium text-slate-700">{user?.name}</span>
                        </button>
                        {profileOpen && (
                            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-1 z-10">
                                <a href="#" className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">Profile</a>
                                <a href="#" className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">Settings</a>
                                <div className="border-t border-slate-200 my-1"></div>
                                <button onClick={logout} className="block w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100">
                                    Logout
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
