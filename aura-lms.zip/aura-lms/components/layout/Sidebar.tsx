import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Role } from '../../types';

interface SidebarProps {
    activeView: string;
    setActiveView: (view: string) => void;
}

const NavLink: React.FC<{
    label: string;
    view: string;
    activeView: string;
    setActiveView: (view: string) => void;
    icon: React.ReactNode;
}> = ({ label, view, activeView, setActiveView, icon }) => {
    const isActive = activeView === view;
    return (
        <button
            onClick={() => setActiveView(view)}
            className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                isActive
                    ? 'bg-brand-blue-500 text-white'
                    : 'text-slate-200 hover:bg-brand-blue-800 hover:text-white'
            }`}
        >
            <span className="mr-3">{icon}</span>
            {label}
        </button>
    );
};

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
    const { user } = useAuth();

    const icons = {
        dashboard: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" /></svg>,
        courses: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 16c1.255 0 2.443-.29 3.5-.804V4.804zM14.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 0114.5 16c1.255 0 2.443-.29 3.5-.804v-10A7.968 7.968 0 0014.5 4z" /></svg>,
        assignments: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" /></svg>,
        grades: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" /><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16z" clipRule="evenodd" /></svg>,
        forum: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M2 5a2 2 0 012-2h7a2 2 0 012 2v4a2 2 0 01-2 2H9l-3 3v-3H4a2 2 0 01-2-2V5z" /><path d="M15 7v2a4 4 0 01-4 4H9.828l-1.766 1.767c.28.149.599.233.938.233h2l3 3v-3h2a2 2 0 002-2V9a2 2 0 00-2-2h-1z" /></svg>,
        students: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0110 14.25c0-2.433-2.13-4.32-4.508-3.516C4.835 11.23 4 12.98 4 15c0 .34.024.673.07 1H12.93zM12 14.25a5 5 0 01-4.406 2.45C7.794 17.545 8 18.223 8 19c0 1.105 1.12 2 2.5 2s2.5-.895 2.5-2c0-.777-.206-1.455-.594-1.95a5.002 5.002 0 01-1.906-.25z" /></svg>,
        attendance: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" /></svg>,
        faculty: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" /></svg>,
        announcements: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" /></svg>,
        timetable: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm-2 5h12v8H4V7z" clipRule="evenodd" /></svg>,
    };

    const studentLinks = [
        { label: 'Dashboard', view: 'dashboard_student', icon: icons.dashboard },
        { label: 'My Courses', view: 'my_courses', icon: icons.courses },
        { label: 'All Courses', view: 'all_courses', icon: icons.courses },
        { label: 'Assignments', view: 'assignments', icon: icons.assignments },
        { label: 'Grades', view: 'grades', icon: icons.grades },
        { label: 'Attendance', view: 'attendance', icon: icons.attendance },
        { label: 'My Faculty', view: 'faculty', icon: icons.faculty },
        { label: 'Announcements', view: 'announcements', icon: icons.announcements },
        { label: 'Timetable', view: 'timetable', icon: icons.timetable },
        { label: 'Forum', view: 'forum', icon: icons.forum },
    ];

    const teacherLinks = [
        { label: 'Dashboard', view: 'dashboard_teacher', icon: icons.dashboard },
        { label: 'Manage Courses', view: 'manage_courses', icon: icons.courses },
        { label: 'Submissions', view: 'submissions', icon: icons.assignments },
        { label: 'Gradebook', view: 'grades', icon: icons.grades },
        { label: 'My Students', view: 'view_students', icon: icons.students },
        { label: 'Forum', view: 'forum', icon: icons.forum },
    ];

    const links = user?.role === Role.Student ? studentLinks : teacherLinks;

    return (
        <aside className="w-64 flex-shrink-0 bg-brand-blue-900 text-white flex flex-col">
            <div className="h-16 flex items-center justify-center text-2xl font-bold border-b border-brand-blue-800">
                Aura LMS
            </div>
            <nav className="flex-1 px-4 py-6 space-y-2">
                {links.map(link => (
                    <NavLink key={link.view} {...link} activeView={activeView} setActiveView={setActiveView} />
                ))}
            </nav>
        </aside>
    );
};

export default Sidebar;